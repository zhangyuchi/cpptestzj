<?php
/*
 *  Test zmsg class
 */
include "zmsg.php";

Zmsg::test();
