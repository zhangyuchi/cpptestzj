# Report 0MQ version
#
# Author: Lev Givon <lev(at)columbia(dot)edu>

import zmq

print "Current 0MQ version is " + zmq.zmq_version()
