zmq_msg_init_data (&request, "Hello", 6, NULL, NULL);
