zmq_setsockopt (socket, ZMQ_IDENTITY, "Lucy", 4);
