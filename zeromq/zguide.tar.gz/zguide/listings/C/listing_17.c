    zmq_setsockopt (subscriber, ZMQ_IDENTITY, "Hello", 5);
