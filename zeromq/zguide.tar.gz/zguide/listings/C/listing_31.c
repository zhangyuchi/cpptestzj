kvmsg_set_prop (kvmsg, "ttl", "%d", randof (30));
