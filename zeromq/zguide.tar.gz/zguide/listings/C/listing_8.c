void *context = zmq_init (1);
